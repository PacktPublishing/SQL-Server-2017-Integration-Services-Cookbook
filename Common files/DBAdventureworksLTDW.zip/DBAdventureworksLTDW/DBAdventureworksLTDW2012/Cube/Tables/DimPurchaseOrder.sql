﻿CREATE TABLE [Cube].[DimPurchaseOrder] (
    [IDPurchaseOrder] INT          IDENTITY (1, 1) NOT NULL,
    [PurchaseOrder]   VARCHAR (25) NULL
);

