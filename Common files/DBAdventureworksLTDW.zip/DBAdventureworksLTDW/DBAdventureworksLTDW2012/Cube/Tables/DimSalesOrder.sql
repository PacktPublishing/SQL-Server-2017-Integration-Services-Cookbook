﻿CREATE TABLE [Cube].[DimSalesOrder] (
    [IDSalesOrder]     INT          IDENTITY (1, 1) NOT NULL,
    [SalesOrderNumber] VARCHAR (25) NOT NULL
);

