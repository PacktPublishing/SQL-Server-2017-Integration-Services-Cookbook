﻿CREATE SCHEMA [SystemLog]
    AUTHORIZATION [dbo];

